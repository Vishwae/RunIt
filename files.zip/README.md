# RunIt! 🏀

**Less coordinating. More hooping.**

A mobile app for scheduled pickup basketball at known courts. Built with React Native + Expo.

![Platform](https://img.shields.io/badge/platform-iOS%20%7C%20Android-orange)
![Status](https://img.shields.io/badge/status-MVP-green)
![Stack](https://img.shields.io/badge/stack-React%20Native%20%2B%20Expo-blue)

---

## What is RunIt!

RunIt! helps players discover, join, host, and coordinate pickup basketball games at local courts. No more fragmented group chats or showing up to empty courts.

**Core features (MVP):**
- Browse nearby games in list + map views
- Filter by skill level, time, and court
- Request to join games with host approval
- Create and host your own games at known courts
- Game-specific chat for coordination
- Upcoming games dashboard (joined, hosting, pending)
- Attendance-based reliability scores
- Push notification system
- Full auth flow (email/password + Google)

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | React Native (Expo) |
| Navigation | React Navigation (bottom tabs + stack) |
| Icons | @expo/vector-icons (Ionicons) |
| State | React useState (local, mock data) |
| Maps | Placeholder (swap in react-native-maps) |
| Data | Mock data layer (ready for Supabase) |

## Project Structure

```
RunIt/
├── App.js                          # Entry point + auth gate
├── app.json                        # Expo config
├── package.json                    # Dependencies
├── babel.config.js
└── src/
    ├── components/
    │   ├── Avatar.js               # User avatar with initials
    │   ├── Badges.js               # Skill + reliability badges
    │   └── GameCard.js             # Game list card component
    ├── data/
    │   └── mockData.js             # All mock data + helper lookups
    ├── navigation/
    │   └── AppNavigator.js         # Tab + stack navigation
    ├── screens/
    │   ├── AuthScreen.js           # Login / signup
    │   ├── HomeScreen.js           # Game feed + map view
    │   ├── GameDetailsScreen.js    # Full game details + join flow
    │   ├── GameChatScreen.js       # Per-game messaging
    │   ├── CreateGameScreen.js     # Create a new game
    │   ├── UpcomingScreen.js       # Joined / hosted / pending
    │   ├── NotificationsScreen.js  # Notification inbox
    │   └── ProfileScreen.js        # Profile + reliability + settings
    └── utils/
        ├── theme.js                # Design system (colors, spacing, etc.)
        └── helpers.js              # Date formatting, distance, etc.
```

## Getting Started

### Prerequisites
- Node.js 18+ and npm
- Expo CLI: `npm install -g expo-cli`
- Expo Go app on your phone (iOS/Android)

### Install & Run

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/runit.git
cd runit

# Install dependencies
npm install

# Start the dev server
npx expo start
```

Scan the QR code with Expo Go (Android) or Camera app (iOS) to preview on your phone.

### Run on Simulator

```bash
# iOS (requires Xcode)
npx expo start --ios

# Android (requires Android Studio)
npx expo start --android

# Web preview
npx expo start --web
```

## Mock Data

The app ships with realistic mock data seeded for **UC Berkeley** area courts:
- 6 Berkeley courts (RSF, San Pablo Park, etc.)
- 8 sample users with reliability scores
- 8 games across multiple days
- Chat messages, notifications, and participation data

All data lives in `src/data/mockData.js`. When you're ready to connect a real backend, swap the helper functions to call Supabase/Firebase.

## Design System

Dark theme with basketball-inspired orange accent (`#FF6B2C`).

| Token | Value |
|-------|-------|
| Background | `#0D0D0D` |
| Card | `#1A1A1A` |
| Orange (brand) | `#FF6B2C` |
| Text primary | `#F5F5F5` |
| Text secondary | `#A0A0A0` |
| Border | `#2A2A2A` |

Skill level badges: green (Beginner), yellow (Intermediate), red (Advanced).

## Screens Overview

1. **Auth** — Login/signup with email or Google
2. **Home** — Scrollable game feed with search + filters; toggle to map view
3. **Game Details** — Full info, roster, host controls, join/leave actions
4. **Create Game** — Pick court, date, time, skill level, max players
5. **Upcoming** — Dashboard of your joined, hosted, and pending games
6. **Game Chat** — Real-time messaging for approved players
7. **Notifications** — Join approvals, reminders, messages
8. **Profile** — Stats, reliability score, settings

## Next Steps (Post-MVP)

- [ ] Connect Supabase backend (auth, database, realtime)
- [ ] Integrate react-native-maps for real map view
- [ ] Expo push notifications
- [ ] Image upload for profiles
- [ ] Recurring game series
- [ ] Advanced filters (distance radius, date range)
- [ ] Attendance marking UI post-game
- [ ] Report / block functionality

---

## Hosting on GitHub

### First-time setup

```bash
# 1. Initialize git (from the RunIt/ directory)
cd RunIt
git init

# 2. Create a .gitignore
cat > .gitignore << 'EOF'
node_modules/
.expo/
dist/
*.jks
*.p8
*.p12
*.key
*.mobileprovision
*.orig.*
web-build/
.env
.env.local
EOF

# 3. Stage and commit
git add .
git commit -m "Initial commit: RunIt! MVP — pickup basketball app"

# 4. Create a repo on GitHub
#    Go to https://github.com/new
#    Name it: runit
#    Do NOT initialize with README (you already have one)
#    Click "Create repository"

# 5. Push to GitHub (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/runit.git
git branch -M main
git push -u origin main
```

### Ongoing workflow

```bash
# After making changes
git add .
git commit -m "describe your changes"
git push
```

### Sharing with collaborators

Anyone can clone and run the app with:
```bash
git clone https://github.com/YOUR_USERNAME/runit.git
cd runit
npm install
npx expo start
```

---

Built for UC Berkeley pickup basketball. Go Bears. 🐻
